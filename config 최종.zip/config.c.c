﻿#include "config.h"
char string[3] = "07";


int main(void)
{
	system("mode con cols=150 lines=40");
	FILE *fp = fopen("bubble_it.txt", "w");
	fprintf(fp, "%s", string);
	fclose(fp);
	//FILE *fp = fopen("bubble_it.txt", "r");
		Menu_SelectMenu();
	if (worktype == 4) {
		int c;

		while ((c = menu_display()) != 4)
		{
			switch (c)
			{
			case 1:sub_back01();
				break;
			case 2: sub_word01();
				break;
			case 3:
				Menu_SelectMenu();
				break;
			}
		}
		return 0;
	}
}
int menu_display(void)
{
	int select;
	int y1 = 0;
	int key;

	do {
		printf("  배경색 변경\n");
		printf("  글자색 변경\n");
		printf("  설정 종료\n\n");
		Menu_draw_arrow(y1);
		key = getch();
		Menu_move_arrow_key(key, &y1, 2);
		system("cls");
	} while (key != 13);

	select = y1 + 1;

	return select;
}

void sub_back01(void)
{
	int c;

	while ((c = sub_background()) != 6)
	{
		back_color(c);
	}
}
int sub_background(void)
{
	int select;
	int y1 = 0;
	int key;
	do {
		printf("   빨강색\n");
		printf("   파란색\n");
		printf("   초록색\n");
		printf("   검정색\n");
		printf("   흰색\n");
		printf("   메인메뉴로 이동\n\n");
		Menu_draw_arrow(y1);
		key = getch();
		Menu_move_arrow_key(key, &y1, 5);
		system("cls");
	} while (key != 13);

	select = y1 + 1;

	return select;
}
void back_color(int type)
{
	system("cls");
	char dos_command[9];

	switch (type) {
	case 1:
		string[0] = '4';
		break;
	case 2:
		string[0] = '1';
		break;
	case 3:
		string[0] = '2';
		break;
	case 4:
		string[0] = '0';
		break;
	case 5:
		string[0] = '7';
		break;

	}
	sprintf(dos_command, "color %s", string);

	system(dos_command);
}

void word_color(int type) {
	system("cls");
	char dos_command[9];

	switch (type) {
	case 1:
		string[1] = '4';
		break;
	case 2:
		string[1] = '1';
		break;
	case 3:
		string[1] = '2';
		break;
	case 4:
		string[1] = '0';
		break;
	case 5:
		string[1] = '7';
		break;
	}
	sprintf(dos_command, "color %s", string);

	system(dos_command);
}


void sub_word01(void)
{
	int c;
	while ((c = sub_word()) != 6)
	{
		word_color(c);
	}
}
int sub_word(void)
{
	int select;
	int y1 = 0;
	int key;
	do {
		system("cls");
		printf("   빨간색\n");
		printf("   파란색\n");
		printf("   초록색\n");
		printf("   검정색\n");
		printf("   흰색\n");
		printf("   메인메뉴로 이동\n\n");
		Menu_draw_arrow(y1);
		key = getch();
		Menu_move_arrow_key(key, &y1, 5);
		system("cls");
	} while (key != 13);

	select = y1 + 1;

	return select;

}

