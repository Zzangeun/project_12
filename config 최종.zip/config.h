#ifndef CONFIG
#define CONFIG
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<Windows.h>
#define _CRT_SECURE_NO_WARNINGS
#include "menu.h"




int menu_display(void);
int sub_background(void);
void sub_back01(void);
int sub_word(void);
void sub_word01(void);
void background(void);
void word(void);
void display_config(void);

void word_color(int type);
void back_color(int type);
char buffer[20];

#endif

